// Copyright (c) 2017 Computer Vision Center (CVC) at the Universitat Autonoma
// de Barcelona (UAB).
//
// This work is licensed under the terms of the MIT license.
// For a copy, see <https://opensource.org/licenses/MIT>.

#include <iostream>
#include "Carla.h"
#include "Carla/Sensor/RayCastLidar.h"
#include "Carla/Actor/ActorBlueprintFunctionLibrary.h"
#include "Math/UnrealMathUtility.h"

#include <compiler/disable-ue4-macros.h>
#include "carla/geom/Math.h"
#include <compiler/enable-ue4-macros.h>

#include "DrawDebugHelpers.h"
#include "Engine/CollisionProfile.h"
#include "Runtime/Engine/Classes/Kismet/KismetMathLibrary.h"


FActorDefinition ARayCastLidar::GetSensorDefinition()
{
	auto Definition = UActorBlueprintFunctionLibrary::MakeLidarDefinition(TEXT("ray_cast"));
	FActorVariation LidarMode;
	LidarMode.Id = TEXT("speed_mode");
	LidarMode.Type = EActorAttributeType::Bool;
	LidarMode.bRestrictToRecommended = false;
	LidarMode.RecommendedValues.Emplace(TEXT("true"));
	Definition.Variations.Append({ LidarMode });
	return Definition;
}

ARayCastLidar::ARayCastLidar(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
	LoadPostProcessingMaterial(
#if PLATFORM_LINUX
		TEXT("Material'/Carla/PostProcessingMaterials/DepthEffectMaterial_GLSL.DepthEffectMaterial_GLSL'")
#else
		TEXT("Material'/Carla/PostProcessingMaterials/DepthEffectMaterial.DepthEffectMaterial'")
#endif
	);

	for (int i = 0; i < MaxCaptureCnt; ++i) {
		FlagLidarBuffer[i] = false;
	}
	//FlagRotator = false;
	NowLidarCamera = 2;
}

void ARayCastLidar::Set(const FActorDescription &ActorDescription)
{
	Super::Set(ActorDescription);
	FLidarDescription LidarDescription;
	UActorBlueprintFunctionLibrary::SetLidar(ActorDescription, LidarDescription);
	UE_LOG(LogCarla, Warning, TEXT("INFO SC %d %d"), ImageWidth, ImageHeight);
	Set(LidarDescription);
}

void ARayCastLidar::Set(const FLidarDescription &LidarDescription)
{
	Description = LidarDescription;
	LidarMeasurement = FLidarMeasurement(Description.Channels);
	CreateLasers();
}


void ARayCastLidar::CreateLasers()
{
	const auto NumberOfLasers = Description.Channels;
	check(NumberOfLasers > 0u);
	const float DeltaAngle = NumberOfLasers == 1u ? 0.f :
		(Description.UpperFovLimit - Description.LowerFovLimit) /
		static_cast<float>(NumberOfLasers - 1);
	LaserAngles.Empty(NumberOfLasers);
	for (auto i = 0u; i < NumberOfLasers; ++i)
	{
		const float VerticalAngle =
			Description.UpperFovLimit - static_cast<float>(i) * DeltaAngle;
		LaserAngles.Emplace(VerticalAngle);
	}
}

void ARayCastLidar::Tick(const float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (LidarSpeedMode) {
		FPixelReader::SendPixelsInRenderThreadToBuffer(*this, LidarBuffer[NowLidarCamera], FlagLidarBuffer[NowLidarCamera], BufferMutex[NowLidarCamera], NowLidarCamera);
	}
	else {
		for (int i = 0; i < MaxCaptureCnt; ++i) {
			FPixelReader::SendPixelsInRenderThreadToBuffer(*this, LidarBuffer[i], FlagLidarBuffer[i], BufferMutex[i], i);
		}
	}
	//FPixelReader::SendPixelsInRenderThreadToBuffer(*this, LidarBuffer[NowLidarCamera], FlagLidarBuffer[NowLidarCamera], BufferMutex[NowLidarCamera], NowLidarCamera);
	ReadPoints(DeltaTime);

	NowLidarCamera = (NowLidarCamera + 1) % MaxCaptureCnt;
	//UE_LOG(LogCarla, Warning, TEXT("INFO %d"), NowLidarCamera);
	auto DataStream = GetDataStream(*this);

	DataStream.Send(*this, LidarMeasurement, DataStream.PopBufferFromPool());
}

void ARayCastLidar::ReadPoints(const float DeltaTime)
{
	const uint32 ChannelCount = Description.Channels;
	const uint32 PointsToScanWithOneLaser =
		FMath::RoundHalfFromZero(
			Description.PointsPerSecond * DeltaTime / float(ChannelCount));

	if (PointsToScanWithOneLaser <= 0)
	{
		UE_LOG(
			LogCarla,
			Warning,
			TEXT("%s: no points requested this frame, try increasing the number of points per second."),
			*GetName());
		return;
	}

	check(ChannelCount == LaserAngles.Num());

	const float CurrentHorizontalAngle = carla::geom::Math::ToDegrees(
		LidarMeasurement.GetHorizontalAngle());
	const float AngleDistanceOfTick = Description.RotationFrequency * 360.0f * DeltaTime;
	const float AngleDistanceOfLaserMeasure = AngleDistanceOfTick / PointsToScanWithOneLaser;

	LidarMeasurement.Reset(ChannelCount * PointsToScanWithOneLaser);
	for (auto i = 0u; i < PointsToScanWithOneLaser; ++i)
	{
		for (auto Channel = 0u; Channel < ChannelCount; ++Channel)
		{
			FVector Point;
			const float Angle = CurrentHorizontalAngle + AngleDistanceOfLaserMeasure * i;
			if (ShootLaser(Channel, Angle, Point))
			{
				LidarMeasurement.WritePoint(Channel, Point);
			}
		}
	}

	const float HorizontalAngle = carla::geom::Math::ToRadians(
		std::fmod(CurrentHorizontalAngle + AngleDistanceOfTick, 360.0f));
	LidarMeasurement.SetHorizontalAngle(HorizontalAngle);
}

bool ARayCastLidar::ShootLaser(const uint32 Channel, const float HorizontalAngle, FVector &XYZ)
{
	
	const float VerticalAngle = LaserAngles[Channel];
	const float DeltaLidarAngle = 360.0 / MaxCaptureCnt;

	//FRotator LidarBodyRot = GetActorRotation();
	FRotator LidarBodyRot = GetActorRotation();
	//UE_LOG(LogCarla, Warning, TEXT("Rot %lf, %lf, %lf"), LidarBodyRot.Pitch, LidarBodyRot.Yaw, LidarBodyRot.Roll);
	FRotator LaserRelativeRot(VerticalAngle, HorizontalAngle, 0);// float InPitch, float InYaw, float InRoll
	FRotator ResultRot = UKismetMathLibrary::ComposeRotators(
		LaserRelativeRot,
		LidarBodyRot
	);
	float LaserPitch = LaserRelativeRot.Pitch;
	float LaserYaw = LaserRelativeRot.Yaw - floor(LaserRelativeRot.Yaw / 360.0) * 360.0;

	float LaserYawBorder = LaserYaw + DeltaLidarAngle / 2;
	if (LaserYawBorder >= 360.0) {
		LaserYawBorder -= 360.0;
	}

	int LidarCameraId = LaserYawBorder / DeltaLidarAngle;
	if (LidarCameraId < 0) {
		LidarCameraId = 0;
	}
	if (LidarCameraId >= MaxCaptureCnt) {
		LidarCameraId = MaxCaptureCnt - 1;
	}
	//LidarCameraId = 0;
	/*
	if(FlagMemLidar != LidarCameraId)
	{
		{
			FScopeLock ScopeLook(&BufferMutex);
			if (!FlagLidarBuffer[LidarCameraId]) {
				return false;
			}
			NowLidarBufferSize = LidarBuffer[LidarCameraId].size();
			//UE_LOG(LogCarla, Warning, TEXT("Lidar Buffer Size %d"), NowLidarBufferSize);
			memcpy(NowLidarBuffer, LidarBuffer[LidarCameraId].data(), (size_t)(sizeof(unsigned char)*NowLidarBufferSize));
		}
		FlagMemLidar = LidarCameraId;
	}
	*/

	if (!FlagLidarBuffer[LidarCameraId]) {
		return false;
	}


	float LaserSubRelativePitch = LaserPitch;
	float LaserSubRelativeYaw = LaserYawBorder - LidarCameraId * DeltaLidarAngle - DeltaLidarAngle / 2.0;
	float ImageDep = (ImageWidth / 2.0) / FMath::Tan(DeltaLidarAngle / 2.0 / 180.0 * PI);
	FVector LaserImageVector = UKismetMathLibrary::GetForwardVector(FRotator(LaserSubRelativePitch, LaserSubRelativeYaw, 0));
	uint32 LaserImageCol = FMath::RoundToInt(ImageWidth / 2.0 + ImageDep / LaserImageVector.X * LaserImageVector.Y);
	uint32 LaserImageRow = FMath::RoundToInt(ImageHeight / 2.0 - ImageDep / LaserImageVector.X * LaserImageVector.Z);
	if (LaserImageCol < 0) {
		LaserImageCol = 0;
	}
	if (LaserImageCol >= ImageWidth) {
		LaserImageCol = ImageWidth - 1;
	}
	if (LaserImageRow < 0) {
		LaserImageRow = 0;
	}
	if (LaserImageRow >= ImageHeight) {
		LaserImageRow = ImageHeight - 1;
	}
	uint32 LaserImageIndex = 4 * (LaserImageRow * ImageWidth + LaserImageCol);

	float LaserDep = 0.0;

	{
		FScopeLock ScopeLook(&BufferMutex[LidarCameraId]);
		unsigned char *LidarBufferPointer = LidarBuffer[LidarCameraId].data();
		LaserDep = ((int(LidarBufferPointer[LaserImageIndex])) * 256.0 * 256.0 + (int(LidarBufferPointer[LaserImageIndex + 1])) * 256.0 + (int)(LidarBufferPointer[LaserImageIndex + 2])) / (256.0 * 256.0 * 256.0 - 1.0) * 100000.0;
	}
	LaserDep /= FMath::Cos(FMath::DegreesToRadians(LaserSubRelativePitch)) * FMath::Cos(FMath::DegreesToRadians(LaserSubRelativeYaw));

		//UE_LOG(LogCarla, Warning, TEXT("Dep :%d, (%lf, %lf) Row %d, Col %d, Index %d, Cid %d, Hor %lf"), LaserDep, LaserSubRelativePitch, LaserSubRelativeYaw, LaserImageRow, LaserImageCol, LaserImageIndex/4, LidarCameraId, HorizontalAngle);
	/*
	XYZ = UKismetMathLibrary::RotateAngleAxis(
		FVector(5000, 0, 0),
		HorizontalAngle,
		FVector(0, 0, 1)
	);
	*/
	//XYZ = FVector(0, 2000 ,0);
	//return true;
	if (LaserDep <= Description.Range) {
		FVector LaserVector = - LaserDep * UKismetMathLibrary::GetForwardVector(ResultRot);
		//float OriLaserVectorZ = LaserDep * FMath::Sin(LaserSubRelativePitch / 180.0 * PI);
		//float OriLaserVectorX = LaserDep * FMath::Cos(LaserSubRelativePitch / 180.0 * PI) * FMath::Cos((LaserSubRelativeYaw + 90.0 - (DeltaLidarAngle / 2)) / 180.0 * PI);
		//float OriLaserVectorY = LaserDep * FMath::Cos(LaserSubRelativePitch / 180.0 * PI) * FMath::Sin((LaserSubRelativeYaw + 90.0 - (DeltaLidarAngle / 2)) / 180.0 * PI);
		//float newLaserVectorX = FMath::Cos(LidarCameraId * DeltaLidarAngle / 180.0 * PI) * OriLaserVectorX - FMath::Sin(LidarCameraId * DeltaLidarAngle / 180.0 * PI) * OriLaserVectorY;
		//float newLaserVectorY = FMath::Sin(LidarCameraId * DeltaLidarAngle / 180.0 * PI) * OriLaserVectorX + FMath::Cos(LidarCameraId * DeltaLidarAngle / 180.0 * PI) * OriLaserVectorY;
		//XYZ = FVector(newLaserVectorX, newLaserVectorY, OriLaserVectorZ);

		XYZ = UKismetMathLibrary::RotateAngleAxis(
			LaserVector,
			-LidarBodyRot.Yaw + 90,
			FVector(0, 0, 1)
		);
		return true;
	}
	else {
		return false;
	}
}

