# types of data
linestring = 1
multilinestring = 2
polygon = 3
multipolygon = 4